var express = require('express');
var app = express();
var server = require('http').createServer(app);
var io = require('socket.io')(server);
var fs = require("fs");

app.use(express.static("."));

app.get('/', function (req, res) {
    res.redirect('index.html');
});
server.listen(3000);


function matrixGen(n, gr, grEat, predator, posion) {
    for (let x = 0; x < n; x++) {
        matrix[x] = []
        for (let y = 0; y < n; y++) {
            matrix[x][y] = 0
        }
    }

    for (let i = 0; i < gr; i++) {
        let x = Math.floor(Math.random() * n)
        let y = Math.floor(Math.random() * n)

        if (matrix[x][y] == 0) {
            matrix[x][y] = 1
        } else {
            i--
        }
    }

    for (let i = 0; i < grEat; i++) {
        let x = Math.floor(Math.random() * n)
        let y = Math.floor(Math.random() * n)

        if (matrix[x][y] == 0) {
            matrix[x][y] = 2
        } else {
            i--
        }
    }
    for (let i = 0; i < predator; i++) {
        let x = Math.floor(Math.random() * n)
        let y = Math.floor(Math.random() * n)

        if (matrix[x][y] == 0) {
            matrix[x][y] = 3
        } else {
            i--
        }

    }
    for (let i = 0; i < posion; i++) {
        let x = Math.floor(Math.random() * n)
        let y = Math.floor(Math.random() * n)

        if (matrix[x][y] == 0) {
            matrix[x][y] = 4
        } else {
            i--
        }
    }

    return n
}
// var n


let matrix = matrixGen(20, 10, 30, 3, 2)
io.sockets.emit('send matrix', matrix)


let grassArr = []
let grassEaterArr = []
let predatorArr = []
let PosionedGrassArr = []
let vochxarArr = []


let Grass = require("./Classes/Grass")
let GrassEater = require("./Classes/GrassEater")
let LivingCreature = require("./Classes/LivingCreature")
let Mard = require("./Classes/Mard")

let PoisonedGrass = require("./Classes/PoisonedGrass")

let Predator = require("./Classes/Predator")
let Vochxar = require("./Classes/Vochxar")




